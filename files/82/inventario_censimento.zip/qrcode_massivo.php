<?php

require '../main.inc.php';
require_once DOL_DOCUMENT_ROOT . '/custom/ultimateqrcode/lib/ultimateqrcode.lib.php';
require_once DOL_DOCUMENT_ROOT . '/custom/ultimateqrcode/includes/phpqrcode/qrlib.php';

$codice_famiglia = !empty($_GET['cod_famiglia']) ? $_GET['cod_famiglia'] : null;
vistaAssetMassivo($codice_famiglia);

function vistaAssetMassivo($codice_famiglia)
{
    global $db, $user;
    $user_id = $user->id;
    
    $sql = "SELECT * FROM llx_asset as a "
            . " inner JOIN tmp_inventario_censimento AS tmp "
            . " ON a.cod_asset = tmp.codice_asset "
            . " WHERE tmp.id_user like  '" . $user_id . "'"
            . "   and codice_famiglia like " . "'" . $codice_famiglia . "'";
    $res = $db->query($sql);

    if ($res)
    {
        while ($rec = $db->fetch_array($res))
        {

            $qr_codice = $rec['cod_asset'];

            $png_web_dir = 'temp/';
            $tempDir = dirname(__FILE__) . DIRECTORY_SEPARATOR . $png_web_dir;
            $qrcode_codice = md5($qr_codice);

            $filename = $tempDir . $qrcode_codice . '.png';
// generating
            QRcode::png($qr_codice, $filename, QR_ECLEVEL_L, 2);

//$codice_asset =  $_GET['qrcode_codice']; //codice asset
            $id = $qr_codice;
            $qr_codice = md5($qr_codice);
            if (!empty($qr_codice))
            {
                $filename = "temp/" . $qr_codice . ".png"; // vado a trovare il file che mi serve per poter stampare

                print "<table>";
                print "<tr>";
                print '<td>';
                print '<img src=' . '"' . $filename . '"' . 'onclick="window.print()">'; // stampa il qrcode
                print '</td>';
                print '</tr>';
                $separa_progressivo = explode("-", $id);
                print '<tr>';
                print '<td><FONT SIZE=1>';
                print $separa_progressivo[0] . "<br>" . $separa_progressivo[1];
                print '</font>';
                print '</td>';
                print '</tr>';
                print "</table>";
                $rr = '<img src=' . '"' . $filename . '"' . 'onclick="window.print()">';
                $rr = '<img src=' . '"' . $filename . '"' . 'onclick="window.print()">';

               

              
            }
        }
    }
}
